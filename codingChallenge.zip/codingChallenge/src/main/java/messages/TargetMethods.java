package messages;

import java.util.HashMap;
import java.util.Map;

/*
 * OPRA Feed Specification: https://www.opradata.com/specs/opra_output_binary_dr_spec.pdf
 * 
 */

public class TargetMethods {

	public TargetMethods() {

	}

	/*
	 * Returns a character array of valid message types based on a given message
	 * category.
	 */
	public static char[] getMessageTypes(byte category) {
		char[] messageTypes;
		switch (category) {
		case 'a':
			messageTypes = new char[] { ' ', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O',
					'P', 'Q', 'R', 'S', 'T', 'X' };
			break;
		case 'd':
		case 'f':
		case 'C':
			messageTypes = new char[] { ' ' };
			break;
		case 'k':
		case 'q':
			messageTypes = new char[] { ' ', 'F', 'I', 'R', 'T', 'A', 'B', 'O', 'C', 'X', 'Y' };
			break;
		case 'H':
			messageTypes = new char[] { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'P' };
			break;
		case 'Y':
			messageTypes = new char[] { ' ', 'I' };
			break;
		default:
			throw new IllegalStateException("Unexpected value: " + category);
		}
		return messageTypes;
	}

	public static char[] getMessageTypes2(byte category) {
		char[] messageTypes = null;
		String s = new String(new byte[] { category });
		Map<String, char[]> messagemap = new HashMap<>();
		messagemap.put("a", new char[] { ' ', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O',
				'P', 'Q', 'R', 'S', 'T', 'X' });
		messagemap.put("d", new char[] { ' ' });
		messagemap.put("f", new char[] { ' ' });
		messagemap.put("C", new char[] { ' ' });
		messagemap.put("k", new char[] { ' ', 'F', 'I', 'R', 'T', 'A', 'B', 'O', 'C', 'X', 'Y' });
		messagemap.put("q", new char[] { ' ', 'F', 'I', 'R', 'T', 'A', 'B', 'O', 'C', 'X', 'Y' });
		messagemap.put("H", new char[] { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'P' });
		messagemap.put("Y", new char[] { ' ', 'I' });
		if (!messagemap.isEmpty() && messagemap.containsKey(s)) {
			messageTypes = messagemap.get(s);
		} else {
			throw new IllegalStateException("Unexpected value: " + category);
		}
		return messageTypes;
	}

	/*
	 * Returns the length of a message based on category, type, and message
	 * indicator
	 */
	public int getMessageLength(char category, char type, char indicator) {
		int messageLength;
		if (category == 'a' && (type == 'A' || type == 'B' || type == 'C' || type == 'D' || type == 'E' || type == 'F'
				|| type == 'G' || type == 'H' || type == 'I' || type == 'J' || type == 'K' || type == 'L' || type == 'M'
				|| type == 'N' || type == 'O' || type == 'P' || type == 'Q' || type == 'R' || type == 'S' || type == 'T'
				|| type == 'X') && indicator == ' ')
			messageLength = 43;
		else if (category == 'd' && type == ' ' && indicator == ' ')
			messageLength = 30;
		else if (category == 'f' && type == ' ' && indicator == ' ')
			messageLength = 72;
		else {
			boolean b = type == ' ' || type == 'A' || type == 'B' || type == 'C' || type == 'F' || type == 'I'
					|| type == 'O' || type == 'R' || type == 'T' || type == 'X' || type == 'Y';
			if (category == 'k' && b) {
				switch (indicator) {
				case 'A':
				case 'B':
				case 'D':
				case 'E':
				case 'F':
				case 'H':
				case 'I':
				case 'J':
				case 'L':
					messageLength = 43;
					break;
				case 'C':
				case 'G':
				case 'K':
				case 'M':
				case 'N':
				case 'P':
					messageLength = 43 + 10; // single appendage
					break;
				case 'O':
					messageLength = 43 + 20; // double appendage
					break;
				default:
					throw new IllegalStateException("Unexpected value: " + indicator);
				}
			} else if (category == 'q' && b) {
				switch (indicator) {
				case 'A':
				case 'B':
				case 'D':
				case 'E':
				case 'F':
				case 'H':
				case 'I':
				case 'J':
				case 'L':
					messageLength = 29;
					break;
				case 'C':
				case 'G':
				case 'K':
				case 'M':
				case 'N':
				case 'P':
					messageLength = 29 + 10; // single appendage
					break;
				case 'O':
					messageLength = 29 + 20; // double appendage
					break;
				default:
					throw new IllegalStateException("Unexpected value: " + indicator);
				}
			} else if (category == 'C' && type == ' ' && indicator == ' ')
				messageLength = 450;
			else if (category == 'H' && (type == 'A' || type == 'B' || type == 'C' || type == 'D' || type == 'E'
					|| type == 'F' || type == 'G' || type == 'H' || type == 'I' || type == 'J' || type == 'K'
					|| type == 'L' || type == 'M' || type == 'N' || type == 'P') && indicator == ' ')
				messageLength = 450;
			else if (category == 'Y' && (type == ' ' || type == 'I') && indicator == ' ')
				messageLength = 27;
			else
				throw new IllegalStateException(
						"Unexpected values: category:" + category + " type:" + type + " indicator" + indicator);
		}
		return messageLength;
	}

}
