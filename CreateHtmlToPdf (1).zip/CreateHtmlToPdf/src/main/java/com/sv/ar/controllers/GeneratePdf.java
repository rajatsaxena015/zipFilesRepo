package com.sv.ar.controllers;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.net.URISyntaxException;
import java.net.URLEncoder;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.itextpdf.html2pdf.HtmlConverter;
import com.itextpdf.io.IOException;
import com.lowagie.text.Document;
import com.lowagie.text.PageSize;
import com.lowagie.text.pdf.PdfWriter;

@RestController
public class GeneratePdf {

	public static final String HTML = "<h1>Hello</h1>" + "<p>This was created using iText</p>"
			+ "<a href='hmkcode.com'>hmkcode.com</a>";

//	public static void main(String[] args) throws FileNotFoundException, IOException {
//		try {
//			HtmlConverter.convertToPdf(HTML, new FileOutputStream("string-to-pdf.pdf"));
//		} catch (Exception e) {
//
//			System.out.println(e);
//		}
//
//		System.out.println("PDF Created!");
//	}

	@GetMapping(value = "/download", produces = "application/MediaType.APPLICATION_PDF_VALUE")
	public void exportPdf(HttpServletRequest request, HttpServletResponse response, @RequestBody String html)
			throws IOException, URISyntaxException, java.io.IOException {

		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		Document document = new Document(PageSize.ID_1);
		PdfWriter.getInstance(document, outputStream);

		HtmlConverter.convertToPdf(new FileInputStream("src/main/resources/static/HtmlFiles/indexl.html"),
				outputStream);

		ByteArrayInputStream is = new ByteArrayInputStream(outputStream.toByteArray());
		response.setContentType("application/pdf");
		response.setHeader("Content-Disposition",
				"attachment;filename=" + URLEncoder.encode("index-to-pdf.pdf", "utf-8"));

		System.out.println("PDF Created!");

		IOUtils.copy(is, response.getOutputStream());
		response.flushBuffer();

	}

	@PostMapping(value = "/download", produces = "application/MediaType.APPLICATION_PDF_VALUE")
	public void exportPdfUsingString(HttpServletRequest request, HttpServletResponse response, @RequestBody String html)
			throws IOException, URISyntaxException, java.io.IOException {

		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		Document document = new Document(PageSize.ID_1);
		PdfWriter.getInstance(document, outputStream);

		HtmlConverter.convertToPdf(html, outputStream);// new
														// FileInputStream("src/main/resources/static/HtmlFiles/indexl.html")

		ByteArrayInputStream is = new ByteArrayInputStream(outputStream.toByteArray());
		response.setContentType("application/pdf");
		response.setHeader("Content-Disposition",
				"attachment;filename=" + URLEncoder.encode("index-to-pdf.pdf", "utf-8"));

		System.out.println("PDF Created!");

		IOUtils.copy(is, response.getOutputStream());
		response.flushBuffer();

	}
}
